
<?php

require "connect.php";
error_reporting(0);
require_once('vendor/php-excel-reader/excel_reader2.php');
require_once('vendor/SpreadsheetReader.php');

if (isset($_POST["submit"]))
{
    
    
  $allowedFileType = ['application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];

  $sunlight=0;
  $temp=0;
  $humidity=0;
  $ec=0;
  $rainfall=0;
  
  if(in_array($_FILES["file"]["type"],$allowedFileType))
  {

       

        $newFileName = uniqid('E-', true) 
    . '.' . strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
   move_uploaded_file($_FILES['file']['tmp_name'], 'excel/' . $newFileName);


    $targetPath = 'excel/'.$newFileName;
        
        $Reader = new SpreadsheetReader($targetPath);
        
       $sheetCount = count($Reader->sheets());
        $z=0;
        $c=-1;
        for($i=0;$i<$sheetCount;$i++)
        {
            
            $Reader->ChangeSheet($i);
            
            foreach ($Reader as $filesop)
            {
          $z1 = mysqli_real_escape_string($conn,$filesop[0]);
          $z2 = mysqli_real_escape_string($conn,$filesop[1]);
          $z3 = mysqli_real_escape_string($conn,$filesop[2]);
            $z4 = mysqli_real_escape_string($conn,$filesop[3]);
             $z5 = mysqli_real_escape_string($conn,$filesop[4]);
             
          
                if(!empty($z1) || !empty($z2)|| !empty($z3))
                {

                 
                  
                    
                  if($z >  0)
                  {
                  	$sunlight+=$z1;
                  	$temp+=$z2;
                  	$humidity+=$z3;
                  	$ec+=$z4;
                  	$rainfall+=$z5;

                     $query = "INSERT into data values('','$newFileName','$z1','$z2','$z3','$z4','$z5')";

                    $result = mysqli_query($conn, $query);
                   

                  }
                }

                     else
                      {
                        $type = "error";
                        $message = "Problem in Importing Excel Data";
                    }

                    $z++;
                    $c++;
                
             }
        

         }



         $d1=$sunlight/$c;
         $d2=$temp/$c;
         $d3=$humidity/$c;
         $d4=$ec/$c;
         $d5=$rainfall/$c;

         $result=($d1+$d2+$d3+$d4+$d5)/5;
         // $result=60;

        if($result < 40)
        {
        	 $value="Yield is not good"; 
        }
        else if($result >= 40 && $result < 60)
        {
        	 $value="Yield is Average";
        }
        else
        {
        	 $value="Yield is Good";
        }

  
 
}
else
{
	echo "<script>alert('Only Select Excel File')</script>";
}

}


?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>
<body>


	<div class="container my-5">
		<h2 class="text-center text-capitalize"> forecast model of agricultural</h2>
    <hr class="bg-success w-25 pb-1">
		<form method="post" action="" enctype="multipart/form-data">
			<div class="row ">
        

			<div class="col-md-5 p-5 m-auto shadow-lg rounded">
        <?php
        if (isset($value)) {
         ?>
         <div class="form-group alert alert-success">
           <?php echo $value;  ?>
        </div>
         <?php
        }
         ?>
			 <div class="form-group">
			 	<label class="h4">Upload excel file</label>
			 	<input type="file" name="file" class="form-control" required>
			 </div>	
			 <div class="form-group">
			 	<button type="submit" name="submit" class="btn btn-success btn-block">Submit</button>
			 </div>
			</div>
		</div>
		</form>
	</div>

	<script type="text/javascript">
		if ( window.history.replaceState ) {
			window.history.replaceState( null, null, window.location.href );
		}
	</script>

</body>
</html>