<?php

$conn=mysqli_connect('localhost','root','','wheather')or die('Database in not connected');

?>