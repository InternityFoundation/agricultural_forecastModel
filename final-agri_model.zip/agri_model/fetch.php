<?php

require 'connect.php';

 $qes=$_POST['que'];

$q=mysqli_query($conn,"select * from question where qes='$qes'");
$data=mysqli_fetch_array($q);

if($data['ans']!='')
{
echo json_encode($data['ans']);
  
}
else
{
echo json_encode('Result not found try again !');
   
}


?>